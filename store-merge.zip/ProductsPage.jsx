import { useState, useEffect, useCallback, useRef } from 'react';
import {
  Package, Plus, Edit3, X, Loader2, CheckCircle2, AlertTriangle,
  Store, ChevronDown, Upload, Trash2, Image as ImageIcon,
} from 'lucide-react';
import toast from 'react-hot-toast';
import DataTable from '../../components/DataTable';
import { erpService, toRpShort } from '../../utils/erp/erpService';
import { createStoreProduct, updateStoreProduct, getStoreCategories } from '../../utils/storeService';

// ── Helpers ───────────────────────────────────────────────────
const toSlug = (name) =>
  name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

const calcMargin = (sell, buy) => {
  if (!sell || !buy || buy <= 0) return null;
  return Math.round(((sell - buy) / buy) * 100);
};

const toBase64 = (file) =>
  new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(r.result);
    r.onerror = rej;
    r.readAsDataURL(file);
  });

// ── Variant Editor ────────────────────────────────────────────
function VariantEditor({ variants, onChange, brand }) {
  const [newKey, setNewKey] = useState('');
  const [newVal, setNewVal] = useState({});

  const PRESETS = brand === 'gpdistro'
    ? [{ k: 'Ukuran', v: ['S','M','L','XL','XXL'] }, { k: 'Warna', v: ['Hitam','Putih','Abu'] }]
    : [{ k: 'Tipe Motor', v: ['Vario 125','Vario 150','Beat','Nmax','Aerox'] }];

  const addPreset = (p) => {
    if (variants[p.k]) return;
    onChange({ ...variants, [p.k]: p.v });
  };

  const addKey = () => {
    if (!newKey.trim() || variants[newKey.trim()]) return;
    onChange({ ...variants, [newKey.trim()]: [] });
    setNewKey('');
  };

  const addVal = (k) => {
    const v = (newVal[k] || '').trim();
    if (!v || (variants[k] || []).includes(v)) return;
    onChange({ ...variants, [k]: [...(variants[k] || []), v] });
    setNewVal(prev => ({ ...prev, [k]: '' }));
  };

  const removeVal = (k, v) => {
    const arr = variants[k].filter(x => x !== v);
    if (!arr.length) { const n = { ...variants }; delete n[k]; onChange(n); }
    else onChange({ ...variants, [k]: arr });
  };

  return (
    <div className="space-y-3">
      {/* Preset buttons */}
      <div className="flex flex-wrap gap-2">
        <span className="text-xs text-[var(--text-muted)] self-center">Preset:</span>
        {PRESETS.map(p => (
          <button key={p.k} type="button" onClick={() => addPreset(p)}
            disabled={!!variants[p.k]}
            className="text-xs px-3 py-1 border border-dashed border-[var(--border)] rounded hover:border-[var(--brand-600)] disabled:opacity-40 disabled:cursor-not-allowed transition-colors">
            + {p.k}
          </button>
        ))}
      </div>

      {/* Existing variant groups */}
      {Object.entries(variants).map(([k, vals]) => (
        <div key={k} className="border border-[var(--border)] rounded-lg p-3">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold uppercase tracking-wide">{k}</span>
            <button type="button" onClick={() => { const n={...variants}; delete n[k]; onChange(n); }}
              className="text-xs text-red-400 hover:text-red-600">Hapus</button>
          </div>
          <div className="flex flex-wrap gap-1.5 mb-2 min-h-[24px]">
            {vals.map(v => (
              <span key={v}
                className="inline-flex items-center gap-1 bg-[var(--bg)] border border-[var(--border)] px-2 py-0.5 rounded text-xs">
                {v}
                <button type="button" onClick={() => removeVal(k, v)}>
                  <X size={10} className="text-[var(--text-muted)] hover:text-red-500"/>
                </button>
              </span>
            ))}
          </div>
          <div className="flex gap-1.5">
            <input value={newVal[k] || ''}
              onChange={e => setNewVal(p => ({ ...p, [k]: e.target.value }))}
              onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), addVal(k))}
              placeholder={`Tambah opsi ${k}...`}
              className="input-base text-xs py-1.5 flex-1"/>
            <button type="button" onClick={() => addVal(k)}
              className="btn-primary text-xs py-1.5 px-3">+</button>
          </div>
        </div>
      ))}

      {/* Add new group */}
      <div className="flex gap-1.5">
        <input value={newKey}
          onChange={e => setNewKey(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), addKey())}
          placeholder="Nama varian baru..."
          className="input-base text-xs py-1.5 flex-1"/>
        <button type="button" onClick={addKey}
          className="btn-outline text-xs py-1.5 px-3">+ Grup</button>
      </div>
    </div>
  );
}

// ── Image Uploader ────────────────────────────────────────────
function ImageUploader({ images, onChange }) {
  const [uploading, setUploading] = useState(false);
  const inputRef = useRef();

  const handleFiles = async (files) => {
    if (!files.length) return;
    setUploading(true);
    try {
      const b64s = await Promise.all(Array.from(files).map(toBase64));
      onChange([...images, ...b64s].slice(0, 6)); // max 6
    } catch { toast.error('Gagal upload gambar'); }
    finally { setUploading(false); }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    handleFiles(e.dataTransfer.files);
  };

  return (
    <div>
      <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 mb-3">
        {images.map((img, i) => (
          <div key={i} className="relative group aspect-square bg-[var(--bg)] border border-[var(--border)] rounded overflow-hidden">
            <img src={img} alt="" className="w-full h-full object-cover"/>
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
              <button type="button" onClick={() => onChange(images.filter((_, j) => j !== i))}
                className="w-7 h-7 bg-red-500 rounded-full flex items-center justify-center">
                <Trash2 size={13} className="text-white"/>
              </button>
            </div>
            {i === 0 && (
              <span className="absolute bottom-0 left-0 right-0 bg-[var(--brand-600)] text-white text-[9px] text-center py-0.5">
                Utama
              </span>
            )}
          </div>
        ))}
        {images.length < 6 && (
          <button type="button"
            onClick={() => inputRef.current?.click()}
            onDrop={handleDrop}
            onDragOver={e => e.preventDefault()}
            className="aspect-square border-2 border-dashed border-[var(--border)] rounded flex flex-col items-center justify-center gap-1 hover:border-[var(--brand-600)] hover:bg-[var(--brand-600)]/5 transition-colors text-[var(--text-muted)] cursor-pointer">
            {uploading
              ? <Loader2 size={18} className="animate-spin text-[var(--brand-600)]"/>
              : <><Upload size={18}/><span className="text-[10px]">Upload</span></>}
          </button>
        )}
      </div>
      <input ref={inputRef} type="file" accept="image/*" multiple className="sr-only"
        onChange={e => handleFiles(e.target.files)}/>
      <p className="text-[10px] text-[var(--text-muted)]">
        Maks 6 foto · JPG, PNG, WebP · Foto pertama = foto utama
      </p>
    </div>
  );
}

// ── Unified Product Modal ─────────────────────────────────────
const TABS = [
  { id: 'basic',   label: 'Info Dasar' },
  { id: 'pricing', label: 'Harga & Stok' },
  { id: 'media',   label: 'Foto & Varian' },
  { id: 'store',   label: 'Toko Online' },
];

const EMPTY = {
  // ERP fields
  branch_id: 1, category_id: '', name: '', sku: '', barcode: '',
  unit: 'pcs', buy_price: 0, sell_price: 0,
  sell_price_mp: '', sell_price_wa: '',
  stock_min: 0, weight: 0.5, notes: '',
  // Store fields
  images: [], variants: {},
  publish_gpdistro: false, publish_gpracing: false,
  store_price_gpdistro: '', store_price_compare_gpdistro: '',
  store_price_gpracing: '', store_price_compare_gpracing: '',
  store_category_gpdistro: '', store_category_gpracing: '',
  short_desc: '', description: '',
  meta_title: '', meta_desc: '', tags: '',
};

function ProductModal({ product, allCategories, onClose, onSuccess }) {
  const isEdit = !!product;
  const [tab, setTab] = useState('basic');
  const [form, setForm] = useState(() => product ? { ...EMPTY, ...product, images: product.images || [], variants: product.variants || {} } : { ...EMPTY });
  const [saving, setSaving] = useState(false);
  const [storeCategories, setStoreCategories] = useState({ gpdistro: [], gpracing: [] });

  const sf = (k, v) => setForm(f => ({ ...f, [k]: v }));

  useEffect(() => {
    Promise.all([
      getStoreCategories('gpdistro').then(r => r.data.data.categories || []).catch(() => []),
      getStoreCategories('gpracing').then(r => r.data.data.categories || []).catch(() => []),
    ]).then(([gd, gr]) => setStoreCategories({ gpdistro: gd, gpracing: gr }));
  }, []);

  // Auto-fill store price from ERP price
  useEffect(() => {
    if (!form.store_price_gpdistro && form.sell_price_mp)
      sf('store_price_gpdistro', form.sell_price_mp);
    if (!form.store_price_gpracing && form.sell_price_mp)
      sf('store_price_gpracing', form.sell_price_mp);
  }, [form.sell_price_mp]);

  const handleSubmit = async () => {
    if (!form.name.trim()) { toast.error('Nama produk wajib diisi'); setTab('basic'); return; }
    if (!form.sell_price) { toast.error('Harga jual wajib diisi'); setTab('pricing'); return; }
    setSaving(true);
    try {
      // 1. Save to ERP
      let erpId = product?.id;
      const erpPayload = {
        branch_id: form.branch_id, category_id: form.category_id || null,
        name: form.name, sku: form.sku, barcode: form.barcode,
        unit: form.unit, buy_price: parseFloat(form.buy_price) || 0,
        sell_price: parseFloat(form.sell_price) || 0,
        sell_price_mp: parseFloat(form.sell_price_mp) || null,
        sell_price_wa: parseFloat(form.sell_price_wa) || null,
        stock_min: parseInt(form.stock_min) || 0,
        weight: parseFloat(form.weight) || 0,
        notes: form.notes,
        // Store fields — saved directly to erp_products
        store_price:         parseFloat(form.store_price_gpracing || form.store_price_gpdistro || form.sell_price_mp || form.sell_price) || 0,
        store_price_compare: parseFloat(form.store_price_compare_gpracing || form.store_price_compare_gpdistro) || 0,
        store_active_gpd:    form.publish_gpdistro ? 1 : 0,
        store_active_gpr:    form.publish_gpracing ? 1 : 0,
        store_images:        form.images || [],
        store_variants:      form.variants || {},
        store_tags:          form.tags ? form.tags.split(',').map(t => t.trim()).filter(Boolean) : [],
        store_short_desc:    form.short_desc || '',
        store_description:   form.description || '',
        store_meta_title:    form.meta_title || form.name,
        store_meta_desc:     form.meta_desc || '',
        store_slug:          toSlug(form.name) + '-' + (form.branch_id || 1),
        store_featured:      form.publish_gpdistro || form.publish_gpracing ? (form.store_featured || false) : false,
      };
      if (isEdit) await erpService.updateProduct(erpId, erpPayload);
      else {
        const r = await erpService.createProduct(erpPayload);
        erpId = r.data.data?.product?.id || r.data.data?.id;
      }

      // 2. Store fields sudah tersimpan di erp_products langsung
      toast.success(isEdit ? 'Produk diperbarui' : 'Produk ditambahkan');
      onSuccess();
      onClose();
    } catch (e) {
      toast.error(e.response?.data?.message || 'Gagal menyimpan produk');
    } finally { setSaving(false); }
  };

  const margin = calcMargin(form.sell_price, form.buy_price);

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-backdrop"/>
      <div className="modal-box max-w-2xl" onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="modal-header">
          <h3 className="text-sm font-bold flex items-center gap-2">
            <Package size={15}/>
            {isEdit ? 'Edit Produk' : 'Tambah Produk Baru'}
          </h3>
          <button onClick={onClose} className="btn-icon-sm"><X size={14}/></button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-[var(--border)] overflow-x-auto">
          {TABS.map(t => (
            <button key={t.id} type="button" onClick={() => setTab(t.id)}
              className={`px-4 py-2.5 text-xs font-semibold whitespace-nowrap transition-colors border-b-2 -mb-px flex-shrink-0 ${
                tab === t.id
                  ? 'border-[var(--brand-600)] text-[var(--brand-600)]'
                  : 'border-transparent text-[var(--text-muted)] hover:text-[var(--text-primary)]'
              }`}>
              {t.label}
              {t.id === 'store' && (form.publish_gpdistro || form.publish_gpracing) && (
                <span className="ml-1.5 w-1.5 h-1.5 rounded-full bg-green-500 inline-block"/>
              )}
            </button>
          ))}
        </div>

        <div className="modal-body">
          {/* ── Tab 1: Info Dasar ──────────────────────── */}
          {tab === 'basic' && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="field-label">Cabang / Brand</label>
                  <select value={form.branch_id}
                    onChange={e => sf('branch_id', parseInt(e.target.value))}
                    className="input-base text-sm">
                    <option value={1}>GP Racing</option>
                    <option value={2}>GP Distro</option>
                  </select>
                </div>
                <div>
                  <label className="field-label">Kategori ERP</label>
                  <select value={form.category_id}
                    onChange={e => sf('category_id', e.target.value)}
                    className="input-base text-sm">
                    <option value="">— Pilih Kategori —</option>
                    {allCategories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </div>
              </div>
              <div>
                <label className="field-label">Nama Produk *</label>
                <input value={form.name}
                  onChange={e => sf('name', e.target.value)}
                  className="input-base" autoFocus placeholder="Nama lengkap produk"/>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="field-label">SKU</label>
                  <input value={form.sku} onChange={e => sf('sku', e.target.value)}
                    className="input-base font-mono text-sm" placeholder="GPR-001"/>
                </div>
                <div>
                  <label className="field-label">Barcode</label>
                  <input value={form.barcode} onChange={e => sf('barcode', e.target.value)}
                    className="input-base font-mono text-sm"/>
                </div>
                <div>
                  <label className="field-label">Satuan</label>
                  <input value={form.unit} onChange={e => sf('unit', e.target.value)}
                    className="input-base" placeholder="pcs"/>
                </div>
              </div>
              <div>
                <label className="field-label">Catatan Internal</label>
                <textarea value={form.notes} onChange={e => sf('notes', e.target.value)}
                  rows={2} className="input-base resize-none text-sm"
                  placeholder="Catatan untuk tim internal (tidak tampil di toko)"/>
              </div>
            </div>
          )}

          {/* ── Tab 2: Harga & Stok ───────────────────── */}
          {tab === 'pricing' && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="field-label">Harga Beli / HPP (Rp)</label>
                  <input type="number" value={form.buy_price}
                    onChange={e => sf('buy_price', e.target.value)}
                    className="input-base" placeholder="0"/>
                </div>
                <div>
                  <label className="field-label">
                    Harga Jual (Rp) *
                    {margin !== null && (
                      <span className={`ml-2 text-xs font-bold ${margin >= 20 ? 'text-green-600' : margin >= 0 ? 'text-amber-600' : 'text-red-500'}`}>
                        {margin >= 0 ? '+' : ''}{margin}% margin
                      </span>
                    )}
                  </label>
                  <input type="number" value={form.sell_price}
                    onChange={e => sf('sell_price', e.target.value)}
                    className="input-base" placeholder="0"/>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="field-label">Harga Marketplace (Rp)</label>
                  <input type="number" value={form.sell_price_mp}
                    onChange={e => sf('sell_price_mp', e.target.value)}
                    className="input-base" placeholder="Opsional"/>
                </div>
                <div>
                  <label className="field-label">Harga WA / Reseller (Rp)</label>
                  <input type="number" value={form.sell_price_wa}
                    onChange={e => sf('sell_price_wa', e.target.value)}
                    className="input-base" placeholder="Opsional"/>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="field-label">Stok Minimum</label>
                  <input type="number" value={form.stock_min}
                    onChange={e => sf('stock_min', e.target.value)}
                    className="input-base" placeholder="0"/>
                  <p className="text-[10px] text-[var(--text-muted)] mt-1">Alert saat stok ≤ angka ini</p>
                </div>
                <div>
                  <label className="field-label">Berat (kg)</label>
                  <input type="number" step="0.1" value={form.weight}
                    onChange={e => sf('weight', e.target.value)}
                    className="input-base" placeholder="0.5"/>
                  <p className="text-[10px] text-[var(--text-muted)] mt-1">Untuk kalkulasi ongkir toko</p>
                </div>
              </div>
            </div>
          )}

          {/* ── Tab 3: Foto & Varian ──────────────────── */}
          {tab === 'media' && (
            <div className="space-y-5">
              <div>
                <label className="field-label mb-2 block">Foto Produk</label>
                <ImageUploader images={form.images} onChange={v => sf('images', v)}/>
              </div>
              <div>
                <label className="field-label mb-2 block">Varian Produk</label>
                <p className="text-[11px] text-[var(--text-muted)] mb-3">
                  Kosongkan jika tidak ada varian.
                </p>
                <VariantEditor
                  variants={form.variants}
                  onChange={v => sf('variants', v)}
                  brand={form.branch_id === 2 ? 'gpdistro' : 'gpracing'}
                />
              </div>
            </div>
          )}

          {/* ── Tab 4: Toko Online ────────────────────── */}
          {tab === 'store' && (
            <div className="space-y-5">
              {/* Publish toggles */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {[
                  { key: 'gpdistro', label: 'GPDISTRO', sub: 'Fashion & Digital Printing', color: '#1a1a2e' },
                  { key: 'gpracing', label: 'GP RACING STORE', sub: 'Spare Part Motor Racing', color: '#dc2626' },
                ].map(b => (
                  <label key={b.key}
                    className={`border-2 rounded-lg p-4 cursor-pointer transition-all ${
                      form[`publish_${b.key}`]
                        ? 'border-[var(--brand-600)] bg-[var(--brand-600)]/5'
                        : 'border-[var(--border)] hover:border-[var(--brand-600)]/40'
                    }`}>
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full flex-shrink-0 mt-0.5" style={{ background: b.color }}/>
                        <div>
                          <p className="text-xs font-bold">{b.label}</p>
                          <p className="text-[10px] text-[var(--text-muted)]">{b.sub}</p>
                        </div>
                      </div>
                      <input type="checkbox"
                        checked={form[`publish_${b.key}`]}
                        onChange={e => sf(`publish_${b.key}`, e.target.checked)}
                        className="w-4 h-4 mt-0.5"/>
                    </div>

                    {form[`publish_${b.key}`] && (
                      <div className="mt-3 pt-3 border-t border-[var(--border)] space-y-2"
                        onClick={e => e.preventDefault()}>
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <p className="text-[10px] text-[var(--text-muted)] mb-1">Harga Jual Toko *</p>
                            <input type="number"
                              value={form[`store_price_${b.key}`]}
                              onChange={e => sf(`store_price_${b.key}`, e.target.value)}
                              className="input-base text-sm py-1.5"
                              placeholder="Harga konsumen"/>
                          </div>
                          <div>
                            <p className="text-[10px] text-[var(--text-muted)] mb-1">Harga Coret (Rp)</p>
                            <input type="number"
                              value={form[`store_price_compare_${b.key}`]}
                              onChange={e => sf(`store_price_compare_${b.key}`, e.target.value)}
                              className="input-base text-sm py-1.5"
                              placeholder="Opsional"/>
                          </div>
                        </div>
                        <div>
                          <p className="text-[10px] text-[var(--text-muted)] mb-1">Kategori Toko</p>
                          <select value={form[`store_category_${b.key}`]}
                            onChange={e => sf(`store_category_${b.key}`, e.target.value)}
                            className="input-base text-sm py-1.5">
                            <option value="">— Tanpa Kategori —</option>
                            {storeCategories[b.key].map(c => (
                              <option key={c.id} value={c.id}>{c.name}</option>
                            ))}
                          </select>
                        </div>
                      </div>
                    )}
                  </label>
                ))}
              </div>

              {/* Description for store */}
              <div>
                <label className="field-label">Deskripsi Singkat (Toko)</label>
                <textarea value={form.short_desc}
                  onChange={e => sf('short_desc', e.target.value)}
                  rows={2} className="input-base mt-1 resize-none text-sm"
                  placeholder="Ringkasan produk untuk listing toko"/>
              </div>
              <div>
                <label className="field-label">Deskripsi Lengkap (Toko)</label>
                <textarea value={form.description}
                  onChange={e => sf('description', e.target.value)}
                  rows={4} className="input-base mt-1 resize-none text-sm"
                  placeholder="Spesifikasi, fitur, cara pemasangan, kompatibilitas motor..."/>
              </div>

              {/* SEO */}
              <div className="border border-[var(--border)] rounded-lg p-4 space-y-3">
                <p className="text-xs font-bold uppercase tracking-widest text-[var(--text-muted)]">SEO</p>
                <div>
                  <label className="field-label">Meta Title</label>
                  <input value={form.meta_title}
                    onChange={e => sf('meta_title', e.target.value)}
                    className="input-base mt-1 text-sm"
                    placeholder={form.name || 'Judul untuk Google (maks 60 karakter)'}
                    maxLength={60}/>
                  <p className="text-[10px] text-[var(--text-muted)] mt-0.5">{(form.meta_title||'').length}/60</p>
                </div>
                <div>
                  <label className="field-label">Meta Description</label>
                  <textarea value={form.meta_desc}
                    onChange={e => sf('meta_desc', e.target.value)}
                    rows={2} className="input-base mt-1 resize-none text-sm"
                    placeholder="Deskripsi untuk Google (maks 160 karakter)" maxLength={160}/>
                  <p className="text-[10px] text-[var(--text-muted)] mt-0.5">{(form.meta_desc||'').length}/160</p>
                </div>
                <div>
                  <label className="field-label">Tags (pisah dengan koma)</label>
                  <input value={form.tags}
                    onChange={e => sf('tags', e.target.value)}
                    className="input-base mt-1 text-sm"
                    placeholder="kampas rem, vario, beat, racing"/>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="modal-footer">
          <button type="button" onClick={onClose} className="btn-secondary">Batal</button>
          <div className="flex items-center gap-2 ml-auto">
            {/* Tab navigation */}
            {tab !== 'basic' && (
              <button type="button"
                onClick={() => setTab(TABS[TABS.findIndex(t => t.id === tab) - 1].id)}
                className="btn-outline text-xs py-2 px-4">← Sebelumnya</button>
            )}
            {tab !== 'store' ? (
              <button type="button"
                onClick={() => setTab(TABS[TABS.findIndex(t => t.id === tab) + 1].id)}
                className="btn-primary text-xs py-2 px-4">Selanjutnya →</button>
            ) : (
              <button type="button" onClick={handleSubmit} disabled={saving}
                className="btn-primary gap-2 disabled:opacity-60">
                {saving
                  ? <Loader2 size={15} className="animate-spin"/>
                  : <CheckCircle2 size={15}/>}
                {saving ? 'Menyimpan...' : isEdit ? 'Simpan Perubahan' : 'Simpan Produk'}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Bulk Publish Modal ─────────────────────────────────────────
const BRAND_INFO = {
  gpdistro: { label: 'GPDISTRO',       sub: 'Fashion & Digital Printing', color: '#1a1a2e' },
  gpracing: { label: 'GP RACING STORE', sub: 'Spare Part Motor Racing',    color: '#dc2626' },
};

function BulkPublishModal({ products, onClose, onDone }) {
  const [brand,    setBrand]    = useState('gpracing');
  const [rows,     setRows]     = useState(() =>
    products.map(p => ({
      id:            p.id,
      name:          p.name,
      sku:           p.sku,
      buy_price:     p.buy_price || 0,
      weight:        p.weight || 0.5,
      stock:         p.stock?.qty || 0,
      unit:          p.unit,
      branch_id:     p.branch_id,
      // editable per-row
      store_price:   p.sell_price_mp || p.sell_price || '',
      price_compare: '',
      category_id:   '',
      skip:          false,
    }))
  );
  const [storeCategories, setStoreCategories] = useState([]);
  const [publishing, setPublishing] = useState(false);
  const [done,       setDone]       = useState([]); // ids that succeeded
  const [failed,     setFailed]     = useState([]); // ids that failed

  useEffect(() => {
    getStoreCategories(brand)
      .then(r => setStoreCategories(r.data.data.categories || []))
      .catch(() => {});
  }, [brand]);

  // Auto-set brand from majority branch_id
  useEffect(() => {
    const gpd = products.filter(p => p.branch_id === 2).length;
    const gpr = products.filter(p => p.branch_id === 1).length;
    setBrand(gpd >= gpr ? 'gpdistro' : 'gpracing');
  }, []);

  const setRow = (id, k, v) =>
    setRows(prev => prev.map(r => r.id === id ? { ...r, [k]: v } : r));

  const activeRows = rows.filter(r => !r.skip);
  const margin = (sell, buy) => {
    if (!sell || !buy || buy <= 0) return null;
    return Math.round(((sell - buy) / buy) * 100);
  };

  const handlePublish = async () => {
    const targets = rows.filter(r => !r.skip && r.store_price);
    if (!targets.length) { toast.error('Tidak ada produk yang dipilih / harga belum diisi'); return; }

    setPublishing(true);
    const ok = [], fail = [];

    for (const r of targets) {
      try {
        await createStoreProduct({
          brand,
          erp_product_id: r.id,
          name:           r.name,
          slug:           toSlug(r.name) + '-' + r.id + '-' + Date.now().toString().slice(-4),
          sku:            r.sku || '',
          short_desc:     r.name,
          price:          parseFloat(r.store_price),
          price_compare:  parseFloat(r.price_compare) || 0,
          weight:         Math.round((parseFloat(r.weight) || 0.5) * 1000),
          stock:          r.stock || 0,
          category_id:    r.category_id || null,
          images:         [],
          variants:       {},
          is_active:      true,
          is_featured:    false,
        });
        ok.push(r.id);
      } catch (e) {
        const msg = e.response?.data?.message || '';
        // Skip duplicate slug — product already published
        if (msg.includes('slug') || msg.includes('Duplicate')) ok.push(r.id);
        else fail.push({ id: r.id, name: r.name, msg });
      }
    }

    setDone(ok);
    setFailed(fail);
    setPublishing(false);

    if (fail.length === 0) {
      toast.success(`${ok.length} produk berhasil dipublish ke ${BRAND_INFO[brand].label}!`);
      setTimeout(onDone, 1500);
    } else {
      toast.error(`${fail.length} produk gagal dipublish`);
    }
  };

  const info = BRAND_INFO[brand];
  const isFinished = done.length > 0 || failed.length > 0;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-backdrop"/>
      <div className="modal-box max-w-3xl" onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="modal-header">
          <div className="flex items-center gap-2">
            <Store size={16} className="text-[var(--brand-600)]"/>
            <h3 className="text-sm font-bold">
              Bulk Publish ke Toko Online
              <span className="ml-2 text-xs font-normal text-[var(--text-muted)]">
                {activeRows.length} produk dipilih
              </span>
            </h3>
          </div>
          <button onClick={onClose} className="btn-icon-sm"><X size={14}/></button>
        </div>

        {/* Result screen */}
        {isFinished && (
          <div className="modal-body">
            <div className="text-center py-6">
              <CheckCircle2 size={48} className="mx-auto text-green-500 mb-3"/>
              <h3 className="font-bold text-lg mb-1">
                {done.length} Produk Berhasil Dipublish
              </h3>
              <p className="text-sm text-[var(--text-muted)] mb-4">
                ke toko <span className="font-bold" style={{ color: info.color }}>{info.label}</span>
              </p>
              {failed.length > 0 && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-left mb-4">
                  <p className="text-xs font-bold text-red-700 mb-2">{failed.length} Gagal:</p>
                  {failed.map(f => (
                    <p key={f.id} className="text-xs text-red-600">• {f.name} — {f.msg}</p>
                  ))}
                </div>
              )}
              <p className="text-xs text-[var(--text-muted)]">
                Lengkapi foto & deskripsi di Toko Online → {brand === 'gpdistro' ? 'GPDISTRO' : 'GP RACING'} → Produk
              </p>
              <button onClick={onDone} className="btn-primary mt-5 px-8">Selesai</button>
            </div>
          </div>
        )}

        {!isFinished && (
          <>
            <div className="modal-body space-y-4">
              {/* Brand picker */}
              <div>
                <p className="field-label mb-2">Publish Semua ke Toko</p>
                <div className="grid grid-cols-2 gap-2">
                  {Object.entries(BRAND_INFO).map(([key, b]) => (
                    <button key={key} type="button" onClick={() => setBrand(key)}
                      className={`p-3 border-2 rounded-lg text-left transition-all ${
                        brand === key
                          ? 'border-[var(--brand-600)] bg-[var(--brand-600)]/5'
                          : 'border-[var(--border)] hover:border-[var(--brand-600)]/40'
                      }`}>
                      <div className="w-3 h-3 rounded-full mb-1.5" style={{ background: b.color }}/>
                      <p className="text-xs font-bold">{b.label}</p>
                      <p className="text-[10px] text-[var(--text-muted)]">{b.sub}</p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Per-product table */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <p className="field-label">Atur Harga per Produk</p>
                  <div className="flex gap-3 text-xs text-[var(--text-muted)]">
                    <button type="button"
                      onClick={() => setRows(r => r.map(x => ({ ...x, skip: false })))}
                      className="hover:text-[var(--brand-600)]">Pilih Semua</button>
                    <button type="button"
                      onClick={() => setRows(r => r.map(x => ({ ...x, skip: true })))}
                      className="hover:text-red-500">Hapus Semua</button>
                  </div>
                </div>

                <div className="border border-[var(--border)] rounded-lg overflow-hidden">
                  {/* Table head */}
                  <div className="grid grid-cols-[24px_1fr_120px_120px_140px] gap-2 px-3 py-2 bg-[var(--bg)] border-b border-[var(--border)] text-[10px] font-bold uppercase tracking-widest text-[var(--text-muted)]">
                    <span/>
                    <span>Produk</span>
                    <span className="text-right">Harga Jual *</span>
                    <span className="text-right">Harga Coret</span>
                    <span>Kategori Toko</span>
                  </div>

                  {/* Rows */}
                  <div className="divide-y divide-[var(--border)] max-h-64 overflow-y-auto">
                    {rows.map(r => (
                      <div key={r.id}
                        className={`grid grid-cols-[24px_1fr_120px_120px_140px] gap-2 px-3 py-2.5 items-center transition-colors ${
                          r.skip ? 'opacity-40 bg-[var(--bg)]' : ''
                        }`}>
                        {/* Checkbox */}
                        <input type="checkbox" checked={!r.skip}
                          onChange={e => setRow(r.id, 'skip', !e.target.checked)}
                          className="w-3.5 h-3.5"/>

                        {/* Product name */}
                        <div className="min-w-0">
                          <p className="text-xs font-medium truncate">{r.name}</p>
                          <p className="text-[10px] text-[var(--text-muted)] font-mono">{r.sku || '—'}</p>
                        </div>

                        {/* Store price */}
                        <div className="relative">
                          <input type="number"
                            value={r.store_price}
                            onChange={e => setRow(r.id, 'store_price', e.target.value)}
                            disabled={r.skip}
                            className="input-base text-xs py-1 text-right w-full"
                            placeholder="0"/>
                          {margin(r.store_price, r.buy_price) !== null && (
                            <span className={`absolute -bottom-4 right-0 text-[9px] font-bold ${
                              margin(r.store_price, r.buy_price) >= 20 ? 'text-green-600'
                              : margin(r.store_price, r.buy_price) >= 0 ? 'text-amber-500'
                              : 'text-red-500'
                            }`}>
                              {margin(r.store_price, r.buy_price) >= 0 ? '+' : ''}
                              {margin(r.store_price, r.buy_price)}%
                            </span>
                          )}
                        </div>

                        {/* Price compare */}
                        <input type="number"
                          value={r.price_compare}
                          onChange={e => setRow(r.id, 'price_compare', e.target.value)}
                          disabled={r.skip}
                          className="input-base text-xs py-1 text-right"
                          placeholder="Opsional"/>

                        {/* Category */}
                        <select value={r.category_id}
                          onChange={e => setRow(r.id, 'category_id', e.target.value)}
                          disabled={r.skip}
                          className="input-base text-xs py-1">
                          <option value="">— Tanpa Kategori —</option>
                          {storeCategories.map(c => (
                            <option key={c.id} value={c.id}>{c.name}</option>
                          ))}
                        </select>
                      </div>
                    ))}
                  </div>
                </div>
                <p className="text-[10px] text-[var(--text-muted)] mt-2">
                  * Harga sudah diisi otomatis dari harga marketplace ERP. Ubah sesuai kebutuhan.
                </p>
              </div>

              {/* Info */}
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-xs text-amber-700">
                <strong>Catatan:</strong> Foto produk belum tersedia — bisa dilengkapi setelah publish
                melalui menu <strong>Toko Online → {brand === 'gpdistro' ? 'GPDISTRO' : 'GP RACING'} → Produk → Edit</strong>.
                Produk yang sudah pernah dipublish akan di-skip otomatis.
              </div>
            </div>

            <div className="modal-footer">
              <button type="button" onClick={onClose} className="btn-secondary">Batal</button>
              <button type="button" onClick={handlePublish}
                disabled={publishing || activeRows.length === 0}
                className="btn-primary gap-2 disabled:opacity-60">
                {publishing
                  ? <><Loader2 size={15} className="animate-spin"/> Publishing {done.length}/{activeRows.length}...</>
                  : <><Store size={15}/> Publish {activeRows.length} Produk ke {info.label}</>}
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────
export default function ProductsPage() {
  const [products,      setProducts]      = useState([]);
  const [categories,    setCategories]    = useState([]);
  const [loading,       setLoading]       = useState(true);
  const [modal,         setModal]         = useState(null);
  const [selected,      setSelected]      = useState(new Set());
  const [bulkPublish,   setBulkPublish]   = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [pRes, cRes] = await Promise.all([
        erpService.getProducts({ limit: 500 }),
        erpService.getCategories({ limit: 200 }),
      ]);
      setProducts(pRes.data.data.products || []);
      setCategories(cRes.data.data.categories || []);
    } catch { toast.error('Gagal memuat produk'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const toggleSelect = (id) =>
    setSelected(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });

  const toggleAll = (filtered) => {
    if (filtered.every(p => selected.has(p.id))) {
      setSelected(new Set());
    } else {
      setSelected(new Set(filtered.map(p => p.id)));
    }
  };

  const selectedProducts = products.filter(p => selected.has(p.id));

  const columns = [
    // Checkbox column
    { key: 'id', label: (
        <input type="checkbox"
          className="w-3.5 h-3.5"
          checked={products.length > 0 && products.every(p => selected.has(p.id))}
          onChange={() => toggleAll(products)}/>
      ),
      width: '32px',
      render: (v) => (
        <input type="checkbox"
          className="w-3.5 h-3.5"
          checked={selected.has(v)}
          onChange={() => toggleSelect(v)}
          onClick={e => e.stopPropagation()}/>
      ),
    },
    { key: 'name', label: 'Nama Produk', sortable: true, render: (v, row) => (
      <div>
        <p className="font-semibold text-[var(--text-primary)] leading-tight">{v}</p>
        {row.sku && <p className="text-[10px] text-[var(--text-muted)] font-mono mt-0.5">{row.sku}</p>}
      </div>
    )},
    { key: 'category', label: 'Kategori', nowrap: true,
      render: v => <span className="text-[var(--text-secondary)]">{v?.name || '—'}</span> },
    { key: 'sell_price', label: 'Harga Jual', sortable: true, align: 'right', nowrap: true,
      render: v => <span className="font-semibold">{toRpShort(v)}</span> },
    { key: 'buy_price', label: 'Harga Beli', sortable: true, align: 'right', nowrap: true,
      render: v => <span className="text-[var(--text-secondary)]">{toRpShort(v)}</span> },
    { key: 'stock', label: 'Stok', align: 'center', nowrap: true, render: (v, row) => {
      const qty = v?.qty || 0; const min = row.stock_min || 0;
      return (
        <span className={`font-bold text-sm ${qty <= min ? 'text-red-500' : 'text-[var(--text-primary)]'}`}>
          {qty < 0 ? <AlertTriangle size={14}/> : qty}{' '}
          <span className="text-[10px] font-normal text-[var(--text-muted)]">{row.unit}</span>
        </span>
      );
    }},
  ];

  return (
    <div className="section animate-fade-in">
      <div className="page-header">
        <div>
          <h1 className="page-title">Produk</h1>
          <p className="body-sm text-[var(--text-muted)]">{products.length} produk</p>
        </div>
        <div className="flex items-center gap-2">
          {/* Bulk publish button — shows when items selected */}
          {selected.size > 0 && (
            <button onClick={() => setBulkPublish(true)}
              className="btn-primary gap-2 animate-fade-in"
              style={{ background: '#059669' }}>
              <Store size={16}/>
              Publish {selected.size} ke Toko
            </button>
          )}
          <button onClick={() => setModal('new')} className="btn-primary">
            <Plus size={16}/> Tambah Produk
          </button>
        </div>
      </div>

      {/* Selection info bar */}
      {selected.size > 0 && (
        <div className="flex items-center justify-between bg-[var(--brand-600)]/10 border border-[var(--brand-600)]/20 rounded-lg px-4 py-2.5 mb-4 animate-fade-in">
          <p className="text-sm font-medium text-[var(--brand-600)]">
            {selected.size} produk dipilih
          </p>
          <div className="flex gap-3">
            <button onClick={() => setSelected(new Set(products.map(p => p.id)))}
              className="text-xs text-[var(--brand-600)] hover:underline">
              Pilih Semua ({products.length})
            </button>
            <button onClick={() => setSelected(new Set())}
              className="text-xs text-[var(--text-muted)] hover:text-red-500">
              Batalkan Pilihan
            </button>
          </div>
        </div>
      )}

      <DataTable
        columns={columns}
        data={products}
        loading={loading}
        searchKeys={['name','sku','barcode']}
        searchPlaceholder="Cari nama, SKU, barcode..."
        emptyIcon={<Package size={40}/>}
        emptyText="Belum ada produk"
        emptyAction={
          <button onClick={() => setModal('new')} className="btn-primary">
            Tambah Produk Pertama
          </button>
        }
        actions={(row) => (
          <button onClick={() => setModal(row)} className="btn-icon-sm" title="Edit">
            <Edit3 size={13}/>
          </button>
        )}
        pageSize={25}
        zebra
      />

      {/* Edit/Add modal */}
      {modal && (
        <ProductModal
          product={modal === 'new' ? null : modal}
          allCategories={categories}
          onClose={() => setModal(null)}
          onSuccess={load}
        />
      )}

      {/* Bulk publish modal */}
      {bulkPublish && selectedProducts.length > 0 && (
        <BulkPublishModal
          products={selectedProducts}
          onClose={() => setBulkPublish(false)}
          onDone={() => {
            setBulkPublish(false);
            setSelected(new Set());
            load();
          }}
        />
      )}
    </div>
  );
}
